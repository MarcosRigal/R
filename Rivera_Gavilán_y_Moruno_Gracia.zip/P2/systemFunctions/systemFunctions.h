#ifndef SYSTEM_FUNCTIONS_H
#define SYSTEM_FUNCTIONS_H

#include "../gameManager/gameManager.h"

using namespace std;

void clear();

void saveSystem();

void loadSystem();

#endif